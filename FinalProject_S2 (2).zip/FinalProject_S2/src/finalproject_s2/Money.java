/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalproject_s2;

/**
 *
 * @author Bri's computer
 */
public class Money {
    private int nickel;
    private int dime;
    private int quarter;
    private int half;
    
    public Money(){
        nickel = 0;
        dime = 0;
        quarter = 0;
        half = 0;
    }

    public Money(int n, int d, int q, int h){
        nickel = n;
        dime = d;
        quarter = q;
        half = h;
    }
    
    public int getNickel() {
        return nickel;
    }

    public int getDime() {
        return dime;
    }

    public int getQuarter() {
        return quarter;
    }

    public int getHalf() {
        return half;
    }

    public void setNickel(int nickel) {
        this.nickel = nickel;
    }

    public void setDime(int dime) {
        this.dime = dime;
    }

    public void setQuarter(int quarter) {
        this.quarter = quarter;
    }

    public void setHalf(int half) {
        this.half = half;
    }
    
    public void incrementNickel(){
        nickel++;
    }
    
    public void decrementNickel(){
        nickel--;
    }
    
    public void incrementDime(){
        dime++;
    }
    
    public void decrementDime(){
        dime--;
    }
    
    public void incrementQuarter(){
        quarter++;
    }
    
    public void decrementQuarter(){
        quarter--;
    }
    
    public void incrementHalf(){
        half++;
    }
    
    public void decrementHalf(){
        half--;
    }
}
