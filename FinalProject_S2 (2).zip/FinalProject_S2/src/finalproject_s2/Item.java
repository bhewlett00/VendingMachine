/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalproject_s2;

/**
 *
 * @author Bri's computer
 */
public class Item {
    private int price;
    private String title;
    private int numItem;

    public Item() {
        price = 0;
        title = "";
        numItem = 0;
    }

        
    public Item(String title, int numItem, int price) {        
        this.price = price;
        this.title = title;
        this.numItem = numItem;
    }

    public int getPrice() {
        return price;
    }
  
    public String getTitle() {
        return title;
    }

    public int getNumItem() {
        return numItem;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setNumItem(int numItem) {
        this.numItem = numItem;
    }
    
    public void decrementNumItems(){
        numItem--;
    }
        
}
