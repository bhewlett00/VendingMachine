/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalproject_s2;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Bri's computer
 */
public class VendingMachine {
    private Item[] items;
    private Money mon;
    private int choice; //which vending machine option
    private final Scanner keyboard;
    private int owed;
    private int entered;    //coins entered to pay
    private boolean exactChange;    //flag to know if the user needs exact change
    private boolean soldOut;    //flag to know if an item is sold out

    public VendingMachine() throws IOException{
        items = new Item[6];
        exactChange = false;
        soldOut = false;
        
        File itemFile = new File("items.txt");
        Scanner inputItem = new Scanner(itemFile);
        
        File moneyFile = new File("money.txt");
        Scanner inputMoney = new Scanner(moneyFile);
        mon = new Money(inputMoney.nextInt(), inputMoney.nextInt(), 
                inputMoney.nextInt(), inputMoney.nextInt());
        
        keyboard = new Scanner(System.in);
        
        while (inputItem.hasNext()){
            for(int i=0; i<items.length; i++){
                items[i] = new Item(inputItem.nextLine(), inputItem.nextInt(), inputItem.nextInt());
                inputItem.nextLine();
            }
        }
        
        inputItem.close();
        inputMoney.close();
        
        

    }
    
    
    public Item[] getItems() {
        return items;
    }

    public Money getMon() {
        return mon;
    }

    public int getChoice() {
        return choice;
    }

    public Scanner getKeyboard() {
        return keyboard;
    }

    public int getOwed() {
        return owed;
    }

    public int getEntered() {
        return entered;
    }

    public boolean isExactChange() {
        return exactChange;
    }

    public boolean isSoldOut() {
        return soldOut;
    }

    public void setItems(Item[] items) {
        this.items = items;
    }

    public void setMon(Money mon) {
        this.mon = mon;
    }

    public void setChoice(int choice) {
        this.choice = choice;
    }

    public void setOwed(int owed) {
        this.owed = owed;
    }

    public void setEntered(int entered) {
        this.entered = entered;
    }

    public void setExactChange(boolean exactChange) {
        this.exactChange = exactChange;
    }

    public void setSoldOut(boolean soldOut) {
        this.soldOut = soldOut;
    }
    
    public void printOptions(){
        System.out.println("Options:");
        // print list of options & price
        soldOut();
        
    }
    
    public void endTransaction(){
        System.out.println("Transaction has been ended.\nGood-bye!");
        System.exit(0);
    }
    
    public void checkInput(){
        int chances = 0;
        while(choice<0 || choice>6 && chances<2){
            chances++;
            System.out.print("Invalid Input! Enter a number between 0 and 6: ");
            choice = keyboard.nextInt();
            keyboard.nextLine(); //clear buffer
            if(choice == 6)
                endTransaction();
        }
        
        if(chances >= 2)
            endTransaction();
    }
    
    public void pay(){
        owed = items[choice].getPrice();
        entered = 0;
        while(owed > 0){
            
            System.out.println("You chose: " + items[choice].getTitle());
            
            double formatPrice = owed / 100.0;
            System.out.printf("You owe: $%.2f\n", formatPrice);
            System.out.print("Enter 50, 25, 10, or 5: ");
            entered = keyboard.nextInt();
            
            while(entered != 50 && entered != 25 && entered != 10 && entered != 5){
                System.out.print("Invalid Input! Enter 50, 25, 10, or 5: ");
                entered = keyboard.nextInt();
            }
            owed = owed - entered;
            incrementCoins();
        }
        
    }
    
    public void makeChange(){
        if(owed<0){
            int change = 0;
            if(!exactChange)
                change = 0-owed;
            System.out.println("Your change: " + change);
            if(change == 45){
                decrementCoins(25);
                decrementCoins(10);
                decrementCoins(10);
            }
            else if(change == 40){
                decrementCoins(25);
                decrementCoins(10);
                decrementCoins(5);
            }
            else if(change == 35){
                decrementCoins(25);
                decrementCoins(10);
            }
            else if(change == 30){
                decrementCoins(25);
                decrementCoins(5);
            }
            else if(change == 25){
                decrementCoins(25);
            }
            else if(change == 20){
                decrementCoins(10);
                decrementCoins(10);
            }
            else if(change == 15){
                decrementCoins(10);
                decrementCoins(5);
            }
            else if(change == 10){
                decrementCoins(10);
            }
            else if(change == 5){
                decrementCoins(5);
            }

        }
        System.out.println("Enjoy your " + items[choice].getTitle());
    }
    
    public void incrementCoins(){
        switch (entered){
            case 50:
                mon.incrementHalf();
                break;
            case 25:
                mon.incrementQuarter();
                break;
            case 10:
                mon.incrementDime();
                break;
            case 5:
                mon.incrementNickel();
                break;
            default:
                break;
        }
    }
    
    public void decrementCoins(int c){
        switch (c){
            case 50:
                mon.decrementHalf();
                break;
            case 25:
                mon.decrementQuarter();
                break;
            case 10:
                mon.decrementDime();
                break;
            case 5:
                mon.decrementNickel();
                break;
            default:
                break;
        }
    }
    
    public void displayWelcomeMessage(){
        System.out.println("Welcome to the Candy Vending Machine!\nEnjoy the options.");
    }
    
    public void writeToFile() throws FileNotFoundException{
        items[choice].decrementNumItems();
        PrintWriter outputItem = new PrintWriter("items.txt");
        PrintWriter outputMoney = new PrintWriter("money.txt");
        
        for(int i=0; i<items.length; i++){
            outputItem.println(items[i].getTitle());
            outputItem.println(items[i].getNumItem());
            outputItem.println(items[i].getPrice());
        }
        outputItem.close();
        outputMoney.println(mon.getNickel());
        outputMoney.println(mon.getDime());
        outputMoney.println(mon.getQuarter());
        outputMoney.println(mon.getHalf());
        outputMoney.close();
    }
    
    public void needExactChange(){
        if(mon.getNickel() < 1 || mon.getDime() < 3 || mon.getQuarter() < 1){
            System.out.println("\n***** WARNING! Exact Change Needed. *****");
            System.out.println("***** No change will be given. *****");
            exactChange = true;
        }
    }
    
    public void soldOut(){
        ArrayList<Integer> indexSoldOut = new ArrayList<>();

        for(int i=0; i<items.length; i++){
            double formatPrice = items[i].getPrice() / 100.0;
            System.out.print(i + ": " + items[i].getTitle() +
                    " --- ");
            if(items[i].getNumItem() <= 0){
                soldOut = true;
                indexSoldOut.add(i);
                System.out.println("** SOLD OUT! **");
            }
            else{
                soldOut = false;
                System.out.printf("$%.2f\n", formatPrice);
            }
        }
        System.out.println("6: QUIT");
        System.out.print("Enter your choice: ");
        choice = keyboard.nextInt();
        keyboard.nextLine(); //clear buffer
        for(int i=0; i<indexSoldOut.size(); i++){
            while(choice == indexSoldOut.get(i)){
                System.out.print("Item sold out. Please choose another item: ");
                choice = keyboard.nextInt();
                keyboard.nextLine(); //clear buffer
            }
        }
 
    }
}
