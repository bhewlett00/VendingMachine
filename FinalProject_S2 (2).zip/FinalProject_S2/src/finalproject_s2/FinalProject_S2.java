/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalproject_s2;

import java.io.IOException;

/**
 * Brianna Hewlett
 * 5/3/19
 * This program will run simulating a vending machine.
 */
public class FinalProject_S2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        VendingMachine r1 = new VendingMachine();
        r1.displayWelcomeMessage();
        r1.needExactChange();
        r1.printOptions();
        if(r1.getChoice() == 6)
            r1.endTransaction();
        r1.checkInput();
        r1.pay();
        r1.makeChange();
        r1.writeToFile();
        
    }
    
}
